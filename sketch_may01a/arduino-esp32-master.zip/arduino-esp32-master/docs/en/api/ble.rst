###
BLE
###

About
-----

.. note:: This is a work in progress project and this section is still missing. If you want to contribute, please see the `Contributions Guide <../contributing.html>`_.

Examples
--------

To get started with BLE, you can try:

BLE Scan
********

.. literalinclude:: ../../../libraries/BLE/examples/Scan/Scan.ino
    :language: arduino

BLE UART
********

.. literalinclude:: ../../../libraries/BLE/examples/UART/UART.ino
    :language: arduino

Complete list of `BLE examples <https://github.com/espressif/arduino-esp32/tree/master/libraries/BLE/examples>`_.
