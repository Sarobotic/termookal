#############
Pulse Counter
#############

About
-----

.. note:: This peripheral is not supported yet by the Arduino API's.
